/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Diansmethod;
/**
 *
 * @author DNS
 */
public class DianNSSMethod { 
    
    static void checkIPK(double ipk){
    
        if (ipk>3.5){
            System.out.println("Cumlaude");
        }else if (ipk>3.0){
            System.out.println("Sangat Memuaskan");
        }else if (ipk>2.75){
            System.out.println("Memuaskan");
        }else if (ipk>2.5){
            System.out.println("Cukup");
        }else {
            System.out.println("Jelek. Kuliah ngapain aja kamu?");
        }
    
    }
    
    public static void main(String[] args) {
    
    checkIPK(3.0);
    
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    /*      INI ADALAH LATIHAN PADA JAVA METHOD
    
    static void cekumur(int umur){
    
        if (umur<18){
        
            System.out.println("Akses ditolak, usia anda belum mencukupi");
            
            }else {
            System.out.println("Akses diberikan, usia anda cukup");
        }
        
    }
    
    static int DNSmthd2(int x, int y){
        return x+y;
    }
    
    static int DNSmthd2 (int x){
    
        return 5+x;
    }
    
    static void DNSmthd( String fname){
    
        System.out.println(fname+" Saya telah mengeksekusinya");
        
        
    }

    /**
     * @param args the command line arguments
     */
    /*
    public static void main(String[] args) {
        
        int z = DNSmthd2(31,5);
        
        DNSmthd("It's done");
        DNSmthd("Done");
        DNSmthd("Not Done");
        System.out.println(DNSmthd2(3));
        System.out.println(DNSmthd2(3,2));
        System.out.println(z);
        cekumur(18);
        
        
        
        // TODO code application logic here
    }*/
    
}

